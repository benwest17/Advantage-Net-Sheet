import React from 'react'

export default function App() {
  return (
    <div style={{ padding: 40, fontFamily: 'Arial' }}>
      <h1>Advantage Title Seller Net Sheet</h1>
      <p>Replace this file with your full Advantage tool code.</p>
    </div>
  )
}
